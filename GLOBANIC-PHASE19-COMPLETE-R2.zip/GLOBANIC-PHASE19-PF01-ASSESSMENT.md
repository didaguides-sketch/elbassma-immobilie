# PHASE 19 — PF-01 FINAL ARCHITECTURAL ASSESSMENT (revision R2)

## Decision
**PF-01 is REVERTED. PF-02 is unchanged and accepted.** The analysis could not establish that removing `SessionProvider` preserves the existing session lifecycle. It established the opposite for users who stay on public routes.

## Evidence

### VERIFIED FROM PROJECT
- `next-auth` 5.0.0-beta.25 on `@auth/core` 0.37.2 (lockfile). Session config is `{ strategy: "jwt" }` with no `maxAge` or `updateAge`, so Auth.js defaults apply (the 30-day `maxAge` default comes from the library, not the project).
- `/api/auth/[...nextauth]` exports `handlers` as GET/POST Route Handlers, which can set cookies.
- `SessionProvider` (no `session` prop) is the **only** caller of `/api/auth/session`. Nothing else in `src` or `tests` calls it.
- `src/middleware.ts` wraps `auth(...)` but its matcher covers only `/admin/*`, `/publisher/*`, `/account/*` and `/notifications/*`. Public routes are never matched.
- On public routes the session is evaluated only during Server Component rendering (`SiteHeader`, the resource and author pages call `auth()`). The project's only server-side cookie write is the locale server action.
- No project document states an intended session lifetime or whether sessions should roll.
- The `jwt` callback re-checks the user in the database whenever the session is evaluated, so suspension stays enforced by server-side `auth()` calls even without the provider.

### VERIFIED FROM AUTHORITATIVE SOURCE / DOCUMENTATION
- **`@auth/core` session action** (source read for 0.26.1 and 0.39.1, which bracket the locked 0.37.2; same logic in both): for the JWT strategy, every call decodes the token, runs `callbacks.jwt`, computes `newExpires = fromDate(sessionMaxAge)`, re-signs the JWT ("Refresh JWT expiry by re-signing it") and sets the cookie again with the new expiry. The `updateAge` gate exists only in the database-session branch.
- **next-auth client:** `__NEXTAUTH._getSession` defaults to a no-op. `SessionProvider`'s effect installs it and calls it on mount, which fetches `/api/auth/session`. Passing a `session` prop avoids that first fetch, and this project passes none. `signIn` and `signOut` call the no-op `_getSession` when no provider is mounted, so they do not need the provider.
- **Next.js 14 docs:** `cookies().set()` is only available in a Server Action or Route Handler; setting cookies is not supported during Server Component rendering.

### INFERRED
- On the four private route prefixes, the middleware wrapper re-issues the refreshed cookie. The exact beta.25 wrapper file was not read; an early `@auth/nextjs` prototype of it does this.
- Server Component `auth()` calls on public pages cannot persist a refreshed cookie (Next restriction above). Whether next-auth attempts the write and swallows the error was not verified.
- Combining these: today the mount-time request gives users a **rolling** session on every route; without it, only visits to the four private prefixes would refresh.

### NOT VERIFIABLE WITHOUT RUNTIME
- Actual `Set-Cookie` headers, cookie and token expiry values, and browser behavior.
- `signIn`/`signOut` in a real browser without the provider (supported by the design above).
- The exact 0.37.2 and beta.25 files, because no `node_modules` or network was available.

## Determination
`SessionProvider`'s mount request refreshes the JWT expiry and cookie on every full page load (and on tab focus) on all routes, including public ones. Removing it makes refresh depend on visiting the four private prefixes, so a user who only browses public pages stops getting a rolling session. That is a session-lifecycle change, and no project document says which lifecycle is intended. Equivalence cannot be established, so PF-01 was reverted.

## What was reverted (PF-01 only)
- `src/app/providers.tsx`: restored byte-for-byte from the Phase 18 baseline (hash equals baseline).
- `src/app/layout.tsx`: restored byte-for-byte from the Phase 18 baseline (hash equals baseline), including the `Providers` import and wrapper.
- The 6 PF-02 files kept their hashes (verified before and after the revert).

## Resulting state (Phase 19 revision R2 = Phase 18 + PF-02)
| File | Finding | Lines |
|---|---|---|
| `app/(public)/authors/[slug]/page.tsx` | PF-02 | +7 / −2 |
| `app/(public)/domains/[slug]/page.tsx` | PF-02 | +7 / −2 |
| `app/(public)/faculties/[id]/page.tsx` | PF-02 | +7 / −2 |
| `app/(public)/publishers/[id]/page.tsx` | PF-02 | +7 / −2 |
| `app/(public)/resources/[type]/[slug]/page.tsx` | PF-02 | +6 / −1 |
| `app/(public)/universities/[slug]/page.tsx` | PF-02 | +7 / −2 |

Modified 6, added 0, deleted 0, unauthorized 0. 41 lines added, 11 removed. Project files 293 (same as Phase 18). Cumulative versus Phase 16B: 92 files.

## Regression after the revert (static)
| Check | Result |
|---|---|
| Modified set equals the 6 PF-02 pages exactly | PASS |
| `SessionProvider` present again in `providers.tsx` only | PASS |
| Unresolved imports across the tree | PASS (none) |
| Route/layout/middleware file set identical to Phase 18 | PASS |
| Dictionaries byte-identical (AR = EN = FR = ES = 1054) | PASS |
| Phase 18 executed and structural checks | PASS |
| Phase 17 Batch 3 invariants (57) | PASS |
| PF-02 structural checks (6 pages) | PASS |
| Prisma, `src/server` incl. auth/RBAC, middleware, API routes, referral, tests, config, `package.json` and lockfile | 0 changed |
| TypeScript typecheck, lint, tests, build, browser, login/logout | NOT RUN |

## Residual conditions
- PF-02: the `cache` import and the dedupe effect were not compiled or measured (NOT RUN). This remains an accepted static-evidence item.
- No performance gain is measured.
- PF-01 is closed as reverted. Revisiting it would first need a decision on the intended session semantics (rolling or fixed), and a runtime test environment.

Superseded: the earlier Phase 19 ZIP (`b172e1897b451a708c05882293c0c0e153a5c14b2bca46b0af252d702609b4ed`) included PF-01. It was not modified or deleted.

## Status
Phase 19 final decision: yours. This revision contains PF-02 only.
