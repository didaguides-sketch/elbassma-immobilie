import type { ReactNode } from "react";
import { SiteHeader } from "@/components/layout/SiteHeader";
import { SiteFooter } from "@/components/layout/SiteFooter";
import { getLocale } from "@/lib/i18n/get-locale";
import { getDictionary } from "@/lib/i18n/get-dictionary";

export default async function PublicLayout({ children }: { children: ReactNode }) {
  const dict = await getDictionary(await getLocale());

  return (
    <div className="flex min-h-screen flex-col bg-white">
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:fixed focus:start-4 focus:top-4 focus:z-50 focus:rounded focus:bg-white focus:px-4 focus:py-2 focus:text-body-sm focus:font-semibold focus:text-globanic-navy"
      >
        {dict.nav.skipToContent}
      </a>
      <SiteHeader />
      <main id="main-content" tabIndex={-1} className="flex-1 focus-visible:ring-0 focus-visible:ring-offset-0">
        {children}
      </main>
      <SiteFooter />
    </div>
  );
}
