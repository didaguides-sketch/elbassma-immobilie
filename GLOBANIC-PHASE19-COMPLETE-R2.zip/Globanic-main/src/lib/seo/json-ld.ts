type ResourceForJsonLd = {
  title: string;
  abstract: string | null;
  description: string | null;
  type: string;
  language: string | null;
  updatedAt: Date;
  publishedAt: Date | null;
  authors: { author: { fullName: string } }[];
  university: { name: string } | null;
};

/**
 * Resource.language is free text (2–30 chars, e.g. "fr" or "Français").
 * A BCP 47-style code is emitted as-is; any other value is emitted as a
 * schema.org Language by name, so a human-readable name is never presented
 * as a language code. Nothing is detected or inferred.
 */
function inLanguageFor(language: string | null) {
  const value = language?.trim();
  if (!value) return {};
  return /^[A-Za-z]{2,3}(-[A-Za-z0-9]{2,8})*$/.test(value)
    ? { inLanguage: value }
    : { inLanguage: { "@type": "Language", name: value } };
}

/**
 * `resourceTypeLabel` is the localized, human-readable resource type
 * (from the existing dictionary), not the internal enum name. The
 * university is a source affiliation, not the content publisher, so it is
 * emitted as `sourceOrganization` rather than `publisher`.
 */
export function buildResourceJsonLd(resource: ResourceForJsonLd, url: string, resourceTypeLabel: string) {
  return {
    "@context": "https://schema.org",
    "@type": "CreativeWork",
    name: resource.title,
    description: resource.abstract || resource.description || undefined,
    learningResourceType: resourceTypeLabel,
    url,
    ...inLanguageFor(resource.language),
    dateModified: resource.updatedAt.toISOString(),
    ...(resource.publishedAt ? { datePublished: resource.publishedAt.toISOString() } : {}),
    ...(resource.authors.length > 0
      ? { author: resource.authors.map((a) => ({ "@type": "Person", name: a.author.fullName })) }
      : {}),
    ...(resource.university
      ? { sourceOrganization: { "@type": "CollegeOrUniversity", name: resource.university.name } }
      : {}),
  };
}

/**
 * Schema.org Article, used specifically for Resource.type === ARTICLE —
 * more semantically correct than the generic CreativeWork used for
 * every other resource type (real headline/author/dates, nothing
 * fabricated). `publisher` here is Globanic itself (the platform that
 * actually published the page), which is the standard schema.org
 * convention for this field — distinct from, and not to be confused
 * with, the business "Publisher" (Resource.uploadedBy) shown elsewhere
 * on the page as a real, separate identity.
 */
export function buildArticleJsonLd(resource: ResourceForJsonLd, url: string) {
  return {
    "@context": "https://schema.org",
    "@type": "Article",
    headline: resource.title,
    description: resource.abstract || resource.description || undefined,
    url,
    ...inLanguageFor(resource.language),
    dateModified: resource.updatedAt.toISOString(),
    ...(resource.publishedAt ? { datePublished: resource.publishedAt.toISOString() } : {}),
    ...(resource.authors.length > 0
      ? { author: resource.authors.map((a) => ({ "@type": "Person", name: a.author.fullName })) }
      : {}),
    publisher: { "@type": "Organization", name: "Globanic" },
  };
}

type AuthorForJsonLd = {
  fullName: string;
  bio: string | null;
  university: { name: string } | null;
};

export function buildAuthorJsonLd(author: AuthorForJsonLd, url: string) {
  return {
    "@context": "https://schema.org",
    "@type": "Person",
    name: author.fullName,
    description: author.bio || undefined,
    url,
    ...(author.university
      ? { affiliation: { "@type": "CollegeOrUniversity", name: author.university.name } }
      : {}),
  };
}

type UniversityForJsonLd = {
  name: string;
  city: string | null;
  country: string | null;
  officialWebsite: string | null;
};

export function buildUniversityJsonLd(university: UniversityForJsonLd, url: string) {
  const hasAddress = !!(university.city || university.country);

  return {
    "@context": "https://schema.org",
    "@type": "CollegeOrUniversity",
    name: university.name,
    url,
    ...(hasAddress
      ? {
          address: {
            "@type": "PostalAddress",
            ...(university.city ? { addressLocality: university.city } : {}),
            ...(university.country ? { addressCountry: university.country } : {}),
          },
        }
      : {}),
    ...(university.officialWebsite ? { sameAs: university.officialWebsite } : {}),
  };
}

/**
 * Schema.org BreadcrumbList mirroring a page's visible breadcrumb exactly:
 * same labels, same order, canonical absolute URLs. Callers must pass only
 * the crumbs actually rendered (no invented levels).
 */
export function buildBreadcrumbJsonLd(items: { name: string; url: string }[]) {
  return {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: items.map((item, index) => ({
      "@type": "ListItem",
      position: index + 1,
      name: item.name,
      item: item.url,
    })),
  };
}
