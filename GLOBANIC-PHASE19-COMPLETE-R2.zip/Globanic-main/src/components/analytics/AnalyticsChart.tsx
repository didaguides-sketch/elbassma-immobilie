"use client";

import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from "recharts";
import type { SeriesPoint } from "@/server/services/analytics-query.service";
import { useLocale, useTranslations } from "@/components/i18n/I18nProvider";
import { formatDate, formatNumber } from "@/lib/i18n/format";

export function AnalyticsChart({ data }: { data: SeriesPoint[] }) {
  const locale = useLocale();
  const t = useTranslations("publisherDashboard");
  const tAdmin = useTranslations("adminDashboard");

  if (data.length === 0) {
    return (
      <div className="flex h-64 items-center justify-center rounded border border-dashed border-slate-200 text-body-sm text-slate-500">
        {t("chartEmptyMessage")}
      </div>
    );
  }

  const formatted = data.map((point) => ({
    ...point,
    label: formatDate(new Date(point.date), locale, { day: "2-digit", month: "2-digit" }),
  }));

  return (
    <>
      <div className="h-64 w-full" aria-hidden="true">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={formatted} margin={{ top: 8, right: 16, left: 0, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#eee" />
            <XAxis dataKey="label" fontSize={12} />
            <YAxis allowDecimals={false} fontSize={12} />
            <Tooltip />
            <Legend />
            <Line type="monotone" dataKey="views" name={t("chartViewsLegend")} stroke="#1E5FD9" strokeWidth={2} />
            <Line type="monotone" dataKey="downloads" name={t("chartDownloadsLegend")} stroke="#3B7DFF" strokeWidth={2} strokeDasharray="4 2" />
          </LineChart>
        </ResponsiveContainer>
      </div>
      <div className="sr-only">
        <table>
          <caption>{t("activityChartHeading")}</caption>
          <thead>
            <tr>
              <th scope="col">{tAdmin("dateColumnHeader")}</th>
              <th scope="col">{t("chartViewsLegend")}</th>
              <th scope="col">{t("chartDownloadsLegend")}</th>
            </tr>
          </thead>
          <tbody>
            {formatted.map((point) => (
              <tr key={point.date}>
                <th scope="row">{point.label}</th>
                <td>{formatNumber(point.views, locale)}</td>
                <td>{formatNumber(point.downloads, locale)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
