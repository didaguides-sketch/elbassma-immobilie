"use client";

import Link from "next/link";
import { useSearchParams, usePathname } from "next/navigation";
import { useTranslations } from "@/components/i18n/I18nProvider";

const BUTTON_CLASS =
  "rounded border border-slate-300 px-4 py-2 text-body-sm font-medium text-globanic-navy transition hover:bg-slate-50";
const UNAVAILABLE_CLASS = "cursor-not-allowed opacity-40";

export function ResourceListPagination({
  page,
  hasMore,
}: {
  page: number;
  hasMore: boolean;
}) {
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const t = useTranslations("common");

  function hrefForPage(targetPage: number) {
    const params = new URLSearchParams(searchParams.toString());
    if (targetPage <= 1) {
      params.delete("page");
    } else {
      params.set("page", String(targetPage));
    }
    const query = params.toString();
    return query ? `${pathname}?${query}` : pathname;
  }

  if (page <= 1 && !hasMore) return null;

  return (
    <nav aria-label={t("paginationLabel")} className="mt-8 flex items-center justify-center gap-4">
      {page > 1 ? (
        <Link href={hrefForPage(page - 1)} className={BUTTON_CLASS}>
          {t("previous")}
        </Link>
      ) : (
        <span aria-disabled="true" className={`${BUTTON_CLASS} ${UNAVAILABLE_CLASS}`}>
          {t("previous")}
        </span>
      )}
      <span aria-current="page" className="text-body-sm text-slate-500">
        {t("pageLabel", { page })}
      </span>
      {hasMore ? (
        <Link href={hrefForPage(page + 1)} className={BUTTON_CLASS}>
          {t("next")}
        </Link>
      ) : (
        <span aria-disabled="true" className={`${BUTTON_CLASS} ${UNAVAILABLE_CLASS}`}>
          {t("next")}
        </span>
      )}
    </nav>
  );
}
