"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import type { ReactNode } from "react";

/**
 * A header navigation link that exposes aria-current="page" only when its
 * href is exactly the current pathname. Presentation/semantics only — no
 * routing, locale or visual state logic.
 */
export function NavLink({
  href,
  className,
  onClick,
  children,
}: {
  href: string;
  className?: string;
  onClick?: () => void;
  children: ReactNode;
}) {
  const pathname = usePathname();

  return (
    <Link href={href} onClick={onClick} className={className} aria-current={pathname === href ? "page" : undefined}>
      {children}
    </Link>
  );
}
