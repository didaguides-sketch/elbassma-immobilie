import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        maroon: {
          900: "#081D40",
          700: "#0B2A5B",
          600: "#123B72",
          500: "#C9A24A",
          100: "#F4ECDA",
        },
        gold: {
          900: "#8A6B2E",
          700: "#B4903E",
          600: "#C9A24A",
          500: "#D4B15F",
          100: "#F4ECDA",
        },
        slate: {
          900: "#20242A",
          800: "#2B3038",
          700: "#454C56",
          500: "#7A828C",
          200: "#E4E6E9",
          100: "#EEF0F2",
        },
        cream: "#FAF8F6",
      },
      fontFamily: {
        heading: ["var(--font-heading)", "sans-serif"],
        body: ["var(--font-body)", "sans-serif"],
      },
      borderRadius: {
        xl2: "1.25rem",
      },
      boxShadow: {
        card: "0 20px 40px -18px rgba(32,36,42,0.25)",
      },
    },
  },
  plugins: [],
};

export default config;
