import { prisma } from "@/lib/prisma";

export type SiteSettings = {
  siteName: string;
  logoUrl: string;
  primaryColor: string;
  phone: string;
  whatsapp: string;
  email: string;
  address: string;
  facebook: string;
  instagram: string;
  youtube: string;
  seoTitle: string;
  seoDescription: string;
};

export const DEFAULT_SETTINGS: SiteSettings = {
  siteName: "El Bassma Immobilier",
  logoUrl: "/logo.png",
  primaryColor: "#0B2A5B",
  phone: "05 56 25 43 01",
  whatsapp: "+213 554 90 87 37",
  email: "contact@elbassmaimmobilier.com",
  address: "Kolea, Tipaza, Algérie, 42032",
  facebook: "",
  instagram: "",
  youtube: "",
  seoTitle: "El Bassma Immobilier — Agence immobilière à Kolea, Tipaza, Algérie",
  seoDescription: "Achat, vente et location de villas, appartements, terrains et locaux commerciaux partout en Algérie.",
};

const SETTINGS_KEY = "site_settings";

export async function getSettings(): Promise<SiteSettings> {
  try {
    const row = await prisma.siteSetting.findUnique({ where: { key: SETTINGS_KEY } });
    if (!row) return DEFAULT_SETTINGS;
    return { ...DEFAULT_SETTINGS, ...(row.value as Partial<SiteSettings>) };
  } catch (err) {
    console.error("[data/settings] getSettings:", err);
    return DEFAULT_SETTINGS;
  }
}

export async function updateSettings(data: SiteSettings) {
  return prisma.siteSetting.upsert({
    where: { key: SETTINGS_KEY },
    create: { key: SETTINGS_KEY, value: data as any },
    update: { value: data as any },
  });
}
