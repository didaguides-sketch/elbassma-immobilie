import { prisma } from "@/lib/prisma";

export type SiteSettings = {
  siteName: string;
  logoUrl: string;
  primaryColor: string;
  phone: string;
  whatsapp: string;
  email: string;
  address: string;
  facebook: string;
  instagram: string;
  youtube: string;
  seoTitle: string;
  seoDescription: string;
};

export const DEFAULT_SETTINGS: SiteSettings = {
  siteName: "Pub Immobilier",
  logoUrl: "/logo.png",
  primaryColor: "#004139",
  phone: "0558 61 33 28",
  whatsapp: "+213 558 61 33 28",
  email: "contact@pubimmobilier.com",
  address: "",
  facebook: "",
  instagram: "",
  youtube: "",
  seoTitle: "Pub Immobilier — La publicité de l'immobilier en Algérie",
  seoDescription: "Pub Immobilier : achat, vente et location de villas, appartements, terrains et locaux commerciaux partout en Algérie.",
};

const SETTINGS_KEY = "site_settings";

export async function getSettings(): Promise<SiteSettings> {
  try {
    const row = await prisma.siteSetting.findUnique({ where: { key: SETTINGS_KEY } });
    if (!row) return DEFAULT_SETTINGS;
    return { ...DEFAULT_SETTINGS, ...(row.value as Partial<SiteSettings>) };
  } catch (err) {
    console.error("[data/settings] getSettings:", err);
    return DEFAULT_SETTINGS;
  }
}

export async function updateSettings(data: SiteSettings) {
  return prisma.siteSetting.upsert({
    where: { key: SETTINGS_KEY },
    create: { key: SETTINGS_KEY, value: data as any },
    update: { value: data as any },
  });
}
