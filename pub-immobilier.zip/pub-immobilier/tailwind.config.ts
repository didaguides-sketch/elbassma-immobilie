import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        // Pub Immobilier brand green (kept under the "maroon" key so every existing
        // component class like `maroon-700` / `bg-gradient-to-br from-maroon-700`
        // picks up the new brand color without touching each file individually.
        maroon: {
          900: "#00201B",
          700: "#004139",
          600: "#0A5A4E",
          500: "#147A67",
          100: "#E3F0EC",
        },
        gold: {
          700: "#8A6D2F",
          500: "#A9915B",
          300: "#C9B888",
          100: "#F1EBDB",
        },
        slate: {
          900: "#20242A",
          800: "#2B3038",
          700: "#454C56",
          500: "#7A828C",
          200: "#E4E6E9",
          100: "#EEF0F2",
        },
        cream: "#FAF8F6",
      },
      fontFamily: {
        heading: ["var(--font-heading)", "sans-serif"],
        body: ["var(--font-body)", "sans-serif"],
      },
      borderRadius: {
        xl2: "1.25rem",
      },
      boxShadow: {
        card: "0 20px 40px -18px rgba(32,36,42,0.25)",
      },
    },
  },
  plugins: [],
};

export default config;
