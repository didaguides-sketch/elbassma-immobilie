import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { runSeed } from "@/lib/seed-data";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const secret = req.nextUrl.searchParams.get("secret");
  const force = req.nextUrl.searchParams.get("force") === "true";

  if (!process.env.SEED_SECRET) {
    return NextResponse.json(
      { error: "SEED_SECRET n'est pas configuré dans les variables d'environnement Vercel." },
      { status: 500 }
    );
  }

  if (secret !== process.env.SEED_SECRET) {
    return NextResponse.json({ error: "Secret invalide." }, { status: 401 });
  }

  try {
    const existing = await prisma.user.count();
    if (existing > 0 && !force) {
      return NextResponse.json({
        message: "La base de données contient déjà des données. Rien n'a été modifié.",
        hint: "Ajoutez &force=true à l'URL si vous voulez vraiment relancer le seed (cela peut créer des doublons).",
      });
    }

    const logs: string[] = [];
    await runSeed(prisma, (msg) => logs.push(msg));

    return NextResponse.json({ success: true, logs });
  } catch (err: any) {
    return NextResponse.json(
      { error: "Échec du seed. Vérifiez DATABASE_URL / DIRECT_URL et que les migrations ont bien été appliquées.", details: err?.message },
      { status: 500 }
    );
  }
}
